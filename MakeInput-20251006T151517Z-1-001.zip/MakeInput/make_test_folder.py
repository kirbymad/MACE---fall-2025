import warnings
import os
warnings.filterwarnings("ignore")

os.makedirs("/home/melissasanseverino/maceML/MakeInput/tests/mace01/", exist_ok=True)